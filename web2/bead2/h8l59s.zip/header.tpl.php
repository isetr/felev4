<?php
require_once 'functions.php';
allow('GET');
?>
<!doctype html>

<meta charset="utf-8">
<title>PHP Beadandó</title>