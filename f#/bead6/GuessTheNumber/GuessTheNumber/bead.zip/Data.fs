﻿namespace GuessTheNumber

open WebSharper
open System.Collections.Generic

module Data =

    let users = new Dictionary<string, int>()