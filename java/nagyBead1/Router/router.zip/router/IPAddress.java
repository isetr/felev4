package router;

import java.util.Arrays;

public class IPAddress {
    private int[] ip;
    public IPAddress(int[] ip) {
        this.ip = Arrays.copyOf(ip, 4);
    }

    public static IPAddress fromString(String ipString) {
        String[] tmp = ipString.split("\\.");
        if(tmp.length != 4) return null;

        int[] tmpIp = new int[4];
        for(int i = 0; i < 4; ++i) tmpIp[i] = Integer.parseInt(tmp[i]);

        return new IPAddress(tmpIp);
    }

    public boolean isTheSame(IPAddress toComp) {
        boolean l = true;
        for(int i = 0; i < 4 && l; ++i){
            l = (ip[i] == toComp.ip[i]);
        }
        return l;
    }

    private boolean isBigger(IPAddress toComp) {
        if(ip[0] > toComp.ip[0]) return true;
        if(ip[0] < toComp.ip[0]) return false;
        if(ip[1] > toComp.ip[1]) return true;
        if(ip[1] < toComp.ip[1]) return false;
        if(ip[2] > toComp.ip[2]) return true;
        if(ip[2] < toComp.ip[2]) return false;
        if(ip[3] > toComp.ip[3]) return true;
        if(ip[3] <= toComp.ip[3]) return false;
        return false;
    }

    public boolean insideRng(IPAddress ip1, IPAddress ip2) {
        boolean biggerThan1 = this.isBigger(ip1) || this.isTheSame(ip1);
        boolean biggerThan2 = this.isBigger(ip2) || this.isTheSame(ip2);
        boolean smallerThan1 = ip1.isBigger(this) || ip1.isTheSame(this);
        boolean smallerThan2 = ip2.isBigger(this) || ip2.isTheSame(this);

        if((biggerThan1 && smallerThan2) || (biggerThan2 && smallerThan1)) return true;
        return false;
    }

    public String toString() {
        return ip[0] + "." + ip[1] + "." + ip[2] + "." + ip[3];
    }
}